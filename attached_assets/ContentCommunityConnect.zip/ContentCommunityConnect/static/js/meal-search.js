/**
 * Meal Search and Selection functionality for SmartCafé
 * This file handles meal search, selection, and nutrient calculation
 */

document.addEventListener('DOMContentLoaded', function() {
    // References to DOM elements
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('search_term');
    const searchResults = document.getElementById('searchResults');
    const mealIdInput = document.getElementById('meal_id');
    const customMealFields = document.getElementById('customMealFields');
    const calculatedNutritionInfo = document.getElementById('calculatedNutritionInfo');
    const portionSelector = document.getElementById('portion_size');
    
    let selectedMeal = null;
    
    // Show/hide custom meal fields based on meal selection
    function toggleCustomMealFields() {
        if (mealIdInput.value) {
            customMealFields.classList.add('d-none');
        } else {
            customMealFields.classList.remove('d-none');
        }
    }
    
    // Initialize with the current state
    toggleCustomMealFields();
    
    // Handle meal selection from search results
    function selectMeal(mealId) {
        // Clear previous selection styling
        const allMealCards = document.querySelectorAll('.meal-card');
        allMealCards.forEach(card => card.classList.remove('border-primary'));
        
        // Highlight selected meal
        const selectedCard = document.getElementById(`meal-${mealId}`);
        if (selectedCard) {
            selectedCard.classList.add('border-primary');
        }
        
        // Set the meal ID in the hidden input
        mealIdInput.value = mealId;
        
        // Update form visibility
        toggleCustomMealFields();
        
        // Fetch meal data and update nutrition information
        fetchMealDetails(mealId);
    }
    
    // Fetch meal details from the API
    function fetchMealDetails(mealId) {
        fetch(`/api/meal/${mealId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                selectedMeal = data;
                updateNutritionInfo();
            })
            .catch(error => {
                console.error('Error fetching meal details:', error);
            });
    }
    
    // Update nutrition information based on selected meal and portion
    function updateNutritionInfo() {
        if (!selectedMeal) {
            calculatedNutritionInfo.innerHTML = '';
            return;
        }
        
        const portionSize = portionSelector.value;
        let multiplier = 1;
        
        // Calculate multiplier based on portion size
        if (portionSize === 'small' && selectedMeal.portion_small) {
            multiplier = selectedMeal.portion_small / 100;
        } else if (portionSize === 'medium' && selectedMeal.portion_medium) {
            multiplier = selectedMeal.portion_medium / 100;
        } else if (portionSize === 'large' && selectedMeal.portion_large) {
            multiplier = selectedMeal.portion_large / 100;
        }
        
        // Calculate nutrition values based on portion
        const calories = Math.round(selectedMeal.calories * multiplier);
        const proteins = selectedMeal.proteins ? Math.round(selectedMeal.proteins * multiplier * 10) / 10 : 0;
        const carbs = selectedMeal.carbs ? Math.round(selectedMeal.carbs * multiplier * 10) / 10 : 0;
        const fats = selectedMeal.fats ? Math.round(selectedMeal.fats * multiplier * 10) / 10 : 0;
        
        // Create nutrition information HTML
        calculatedNutritionInfo.innerHTML = `
            <div class="card bg-dark text-white">
                <div class="card-header">
                    <h5 class="card-title mb-0">Nutrition Info</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span>Calories:</span>
                        <strong>${calories} kcal</strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Proteins:</span>
                        <strong>${proteins}g</strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Carbs:</span>
                        <strong>${carbs}g</strong>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Fats:</span>
                        <strong>${fats}g</strong>
                    </div>
                </div>
            </div>
        `;
    }
    
    // Event listener for portion size change
    if (portionSelector) {
        portionSelector.addEventListener('change', updateNutritionInfo);
    }
    
    // Event delegation for meal selection
    if (searchResults) {
        searchResults.addEventListener('click', function(e) {
            // Find closest meal card if it exists
            const mealCard = e.target.closest('.meal-card');
            if (mealCard && mealCard.dataset.mealId) {
                selectMeal(mealCard.dataset.mealId);
                return;
            }
            
            // Handle CSV food selection
            const csvFoodBtn = e.target.closest('.select-csv-food');
            if (csvFoodBtn) {
                const name = csvFoodBtn.dataset.name;
                const calories = parseFloat(csvFoodBtn.dataset.calories);
                const proteins = parseFloat(csvFoodBtn.dataset.proteins);
                const carbs = parseFloat(csvFoodBtn.dataset.carbs);
                const fats = parseFloat(csvFoodBtn.dataset.fats);
                
                // Clear any previous meal selection
                mealIdInput.value = '';
                
                // Show custom meal fields and fill them with CSV data
                customMealFields.classList.remove('d-none');
                
                // Fill the form fields with the CSV data
                document.getElementById('custom_meal_name').value = name;
                document.getElementById('custom_meal_calories').value = calories;
                document.getElementById('custom_meal_proteins').value = proteins;
                document.getElementById('custom_meal_carbs').value = carbs;
                document.getElementById('custom_meal_fats').value = fats;
                
                // Create nutrition info display
                calculatedNutritionInfo.innerHTML = `
                    <div class="card bg-dark text-white">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Nutrition Info (from CSV)</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-2">
                                <span>Calories:</span>
                                <strong>${calories} kcal</strong>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Proteins:</span>
                                <strong>${proteins}g</strong>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Carbs:</span>
                                <strong>${carbs}g</strong>
                            </div>
                            <div class="d-flex justify-content-between">
                                <span>Fats:</span>
                                <strong>${fats}g</strong>
                            </div>
                        </div>
                    </div>
                `;
                
                // Highlight the selected food card
                const allFoodCards = document.querySelectorAll('.food-card');
                allFoodCards.forEach(card => card.classList.remove('border-primary'));
                csvFoodBtn.closest('.food-card').classList.add('border-primary');
            }
        });
    }
    
    // Process any pre-selected meal (from URL parameters)
    const preselectedMealId = mealIdInput.value;
    if (preselectedMealId) {
        selectMeal(preselectedMealId);
    }
    
    // Clear meal selection button
    const clearSelectionBtn = document.getElementById('clearMealSelection');
    if (clearSelectionBtn) {
        clearSelectionBtn.addEventListener('click', function(e) {
            e.preventDefault();
            mealIdInput.value = '';
            selectedMeal = null;
            calculatedNutritionInfo.innerHTML = '';
            
            // Clear custom meal fields
            document.getElementById('custom_meal_name').value = '';
            document.getElementById('custom_meal_calories').value = '';
            document.getElementById('custom_meal_proteins').value = '';
            document.getElementById('custom_meal_carbs').value = '';
            document.getElementById('custom_meal_fats').value = '';
            
            // Remove selection highlight for database meals
            const allMealCards = document.querySelectorAll('.meal-card');
            allMealCards.forEach(card => card.classList.remove('border-primary'));
            
            // Remove selection highlight for CSV foods
            const allFoodCards = document.querySelectorAll('.food-card');
            allFoodCards.forEach(card => card.classList.remove('border-primary'));
            
            // Show custom meal fields
            toggleCustomMealFields();
        });
    }
});
