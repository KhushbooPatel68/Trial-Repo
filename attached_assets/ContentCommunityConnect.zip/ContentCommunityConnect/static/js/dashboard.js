/**
 * Dashboard functionality for SmartCafé
 * This file handles the initialization and updates of the dashboard charts and data
 */

document.addEventListener('DOMContentLoaded', function() {
    // Check if we're on the dashboard page
    if (document.getElementById('caloriesChart')) {
        initializeDashboard();
    }
});

/**
 * Initialize dashboard charts and components
 */
function initializeDashboard() {
    // Get dashboard data from the page
    const weeklyDataElement = document.getElementById('weeklyData');
    const dailyGoalElement = document.getElementById('dailyCalorieGoal');
    const dailyNutritionElement = document.getElementById('dailyNutrition');
    const mealDistributionElement = document.getElementById('mealDistribution');
    
    if (!weeklyDataElement || !dailyGoalElement || !dailyNutritionElement || !mealDistributionElement) {
        console.error('Missing required data elements for dashboard');
        return;
    }
    
    try {
        // Parse JSON data from HTML data attributes
        const weeklyData = JSON.parse(weeklyDataElement.dataset.weekly);
        const dailyGoal = parseInt(dailyGoalElement.dataset.goal, 10);
        const dailyNutrition = JSON.parse(dailyNutritionElement.dataset.nutrition);
        const mealDistribution = JSON.parse(mealDistributionElement.dataset.distribution);
        
        // Initialize charts
        createCaloriesChart('caloriesChart', weeklyData, dailyGoal);
        createMacrosPieChart('macrosChart', dailyNutrition);
        createMacrosTrendChart('macrosTrendChart', weeklyData);
        
        // Only create meal distribution chart if we have data
        if (Object.keys(mealDistribution).length > 0) {
            createMealDistributionChart('mealDistributionChart', mealDistribution);
        } else {
            // Show a message if no meal data exists
            document.getElementById('mealDistributionChart').innerHTML = 
                '<div class="text-center p-4 text-muted">No meal data for today</div>';
        }
        
        // Update progress bars for daily nutrition
        updateNutritionProgress(dailyNutrition, dailyGoal);
        
    } catch (error) {
        console.error('Error initializing dashboard:', error);
    }
}

/**
 * Update nutrition progress bars
 * @param {Object} nutrition - Daily nutrition data
 * @param {number} calorieGoal - Daily calorie goal
 */
function updateNutritionProgress(nutrition, calorieGoal) {
    // Calculate calorie percentage
    const caloriePercentage = Math.min(Math.round((nutrition.calories / calorieGoal) * 100), 100);
    const calorieProgressBar = document.getElementById('calorieProgress');
    
    if (calorieProgressBar) {
        calorieProgressBar.style.width = `${caloriePercentage}%`;
        calorieProgressBar.setAttribute('aria-valuenow', caloriePercentage);
        
        // Set color based on percentage
        if (caloriePercentage > 95) {
            calorieProgressBar.classList.add('bg-danger');
        } else if (caloriePercentage > 75) {
            calorieProgressBar.classList.add('bg-warning');
        } else {
            calorieProgressBar.classList.add('bg-success');
        }
    }
    
    // Calculate macronutrient distribution
    const totalMacros = nutrition.proteins + nutrition.carbs + nutrition.fats;
    
    if (totalMacros > 0) {
        const proteinPercentage = Math.round((nutrition.proteins / totalMacros) * 100);
        const carbsPercentage = Math.round((nutrition.carbs / totalMacros) * 100);
        const fatsPercentage = Math.round((nutrition.fats / totalMacros) * 100);
        
        const proteinProgress = document.getElementById('proteinProgress');
        const carbsProgress = document.getElementById('carbsProgress');
        const fatsProgress = document.getElementById('fatsProgress');
        
        if (proteinProgress) {
            proteinProgress.style.width = `${proteinPercentage}%`;
            proteinProgress.setAttribute('aria-valuenow', proteinPercentage);
        }
        
        if (carbsProgress) {
            carbsProgress.style.width = `${carbsPercentage}%`;
            carbsProgress.setAttribute('aria-valuenow', carbsPercentage);
        }
        
        if (fatsProgress) {
            fatsProgress.style.width = `${fatsPercentage}%`;
            fatsProgress.setAttribute('aria-valuenow', fatsPercentage);
        }
    }
}

/**
 * Change the date for the dashboard
 * @param {string} date - Date in YYYY-MM-DD format
 */
function changeDate(date) {
    window.location.href = `/dashboard?date=${date}`;
}

// Date selection handling
document.addEventListener('DOMContentLoaded', function() {
    const dateSelector = document.getElementById('dateSelector');
    if (dateSelector) {
        dateSelector.addEventListener('change', function() {
            changeDate(this.value);
        });
    }
    
    // Next and previous day buttons
    const prevDayBtn = document.getElementById('prevDay');
    const nextDayBtn = document.getElementById('nextDay');
    const currentDate = document.getElementById('dateSelector')?.value || new Date().toISOString().split('T')[0];
    
    if (prevDayBtn) {
        prevDayBtn.addEventListener('click', function() {
            const date = new Date(currentDate);
            date.setDate(date.getDate() - 1);
            changeDate(date.toISOString().split('T')[0]);
        });
    }
    
    if (nextDayBtn) {
        nextDayBtn.addEventListener('click', function() {
            const date = new Date(currentDate);
            date.setDate(date.getDate() + 1);
            changeDate(date.toISOString().split('T')[0]);
        });
    }
});
