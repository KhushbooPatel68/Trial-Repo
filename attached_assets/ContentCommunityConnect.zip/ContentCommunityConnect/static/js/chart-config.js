/**
 * Chart.js configurations for SmartCafé dashboard
 * This file contains functions for setting up different charts used in the dashboard
 */

// Set global defaults for all charts
Chart.defaults.color = '#ffffff';
Chart.defaults.font.family = "'Poppins', 'Segoe UI', sans-serif";

/**
 * Creates a calories chart to show daily calorie intake for the past week
 * @param {string} elementId - The ID of the canvas element
 * @param {Object} data - Chart data including dates and calorie values
 * @param {number} dailyGoal - User's daily calorie goal
 */
function createCaloriesChart(elementId, data, dailyGoal) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    // Create gradient for the bar background
    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, 'rgba(54, 162, 235, 0.8)');
    gradient.addColorStop(1, 'rgba(54, 162, 235, 0.1)');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.dates.map(date => {
                // Format the date to display only day and month
                const d = new Date(date);
                return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
            }),
            datasets: [
                {
                    label: 'Calories',
                    data: data.calories,
                    backgroundColor: gradient,
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1,
                    borderRadius: 5,
                    hoverBackgroundColor: 'rgba(54, 162, 235, 0.9)'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.7)',
                    padding: 10,
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    titleFont: {
                        size: 14
                    },
                    bodyFont: {
                        size: 13
                    },
                    displayColors: false
                },
                annotation: {
                    annotations: {
                        line1: {
                            type: 'line',
                            yMin: dailyGoal,
                            yMax: dailyGoal,
                            borderColor: 'rgba(255, 159, 64, 0.8)',
                            borderWidth: 2,
                            borderDash: [5, 5],
                            label: {
                                display: true,
                                content: 'Goal',
                                position: 'end',
                                backgroundColor: 'rgba(255, 159, 64, 0.8)',
                                color: '#ffffff'
                            }
                        }
                    }
                }
            }
        }
    });
}

/**
 * Creates a macronutrient chart showing protein, carbs, and fat distribution
 * @param {string} elementId - The ID of the canvas element
 * @param {Object} data - Nutrition data with protein, carbs, and fat values
 */
function createMacrosPieChart(elementId, data) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Protein', 'Carbs', 'Fats'],
            datasets: [{
                data: [data.proteins, data.carbs, data.fats],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.8)',
                    'rgba(75, 192, 192, 0.8)',
                    'rgba(255, 205, 86, 0.8)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(255, 205, 86, 1)'
                ],
                borderWidth: 1,
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '65%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.formattedValue || '';
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((context.raw / total) * 100);
                            return `${label}: ${value}g (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

/**
 * Creates a meal type distribution chart showing calories by meal type
 * @param {string} elementId - The ID of the canvas element
 * @param {Object} data - Meal distribution data
 */
function createMealDistributionChart(elementId, data) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    // Extract meal types and values from the data object
    const mealTypes = Object.keys(data);
    const mealValues = Object.values(data);
    
    // Define colors for different meal types
    const backgroundColors = {
        'breakfast': 'rgba(255, 159, 64, 0.7)',
        'lunch': 'rgba(54, 162, 235, 0.7)',
        'dinner': 'rgba(153, 102, 255, 0.7)',
        'snack': 'rgba(75, 192, 192, 0.7)'
    };
    
    const borderColors = {
        'breakfast': 'rgba(255, 159, 64, 1)',
        'lunch': 'rgba(54, 162, 235, 1)',
        'dinner': 'rgba(153, 102, 255, 1)',
        'snack': 'rgba(75, 192, 192, 1)'
    };
    
    // Map colors based on meal types
    const colors = mealTypes.map(type => backgroundColors[type] || 'rgba(201, 203, 207, 0.7)');
    const borders = mealTypes.map(type => borderColors[type] || 'rgba(201, 203, 207, 1)');
    
    new Chart(ctx, {
        type: 'polarArea',
        data: {
            labels: mealTypes.map(type => type.charAt(0).toUpperCase() + type.slice(1)),
            datasets: [{
                data: mealValues,
                backgroundColor: colors,
                borderColor: borders,
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    ticks: {
                        display: false
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.label}: ${context.formattedValue} calories`;
                        }
                    }
                }
            }
        }
    });
}

/**
 * Creates a weekly macronutrient trends chart
 * @param {string} elementId - The ID of the canvas element
 * @param {Object} data - Weekly macronutrient data
 */
function createMacrosTrendChart(elementId, data) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.dates.map(date => {
                const d = new Date(date);
                return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
            }),
            datasets: [
                {
                    label: 'Protein',
                    data: data.macros.proteins,
                    borderColor: 'rgba(255, 99, 132, 1)',
                    backgroundColor: 'rgba(255, 99, 132, 0.1)',
                    tension: 0.3,
                    fill: false
                },
                {
                    label: 'Carbs',
                    data: data.macros.carbs,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    backgroundColor: 'rgba(75, 192, 192, 0.1)',
                    tension: 0.3,
                    fill: false
                },
                {
                    label: 'Fats',
                    data: data.macros.fats,
                    borderColor: 'rgba(255, 205, 86, 1)',
                    backgroundColor: 'rgba(255, 205, 86, 0.1)',
                    tension: 0.3,
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            }
        }
    });
}
